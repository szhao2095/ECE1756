#ifndef NETLIST_CLEANUP_H
#define NETLIST_CLEANUP_H

void remove_unused_logic(netlist_t *netlist);

#endif
