#ifndef VERILOG_BISON_USER_DEFINED
#define VERILOG_BISON_USER_DEFINED
int yyparse (void);
#endif
