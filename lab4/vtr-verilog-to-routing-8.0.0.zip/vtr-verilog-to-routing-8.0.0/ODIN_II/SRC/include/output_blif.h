#ifndef OUTPUT_BLIF_H
#define OUTPUT_BLIF_H

void output_blif(char *file_name, netlist_t *netlist);

#endif

