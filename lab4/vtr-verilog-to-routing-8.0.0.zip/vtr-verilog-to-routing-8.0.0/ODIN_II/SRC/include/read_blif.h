#ifndef READ_BLIF_H
#define READ_BLIF_H

netlist_t *read_blif();
extern int line_count;

#endif

