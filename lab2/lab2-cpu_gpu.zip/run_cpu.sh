for var in "$@"
do
	./conv_cpu hinton.pgm "$var"
done
